# Publish Dungeon Quest v0.5 with GitHub Pages

1. Sign in at https://github.com and create a **public** repository named `dungeon-quest` (or another name).
2. On the repository's **Code** tab, choose **Add file → Upload files**. Upload the **contents of this extracted ZIP**, not the ZIP itself. Keep `index.html` at the repository root and preserve the `sprites/` and `icons/` directories. Commit the files to `main`.
3. Open **Settings → Pages**. Under **Build and deployment**, select **Deploy from a branch**, then branch `main` and folder `/ (root)`. Save.
4. Wait for deployment. Visit `https://YOUR-USERNAME.github.io/dungeon-quest/` (replace username and repository name if different).
5. On Samsung Galaxy S26 Ultra, open the HTTPS URL in Chrome and use the browser menu's **Install app** or **Add to Home screen** option.

## Updating
Upload changed files to the same paths and commit. A new deployment follows automatically. The service worker's cache name should be incremented for every release containing changed files to ensure installed clients receive fresh assets.

## Notes
- This package is a static site; no server, database, APK, or paid hosting is needed.
- The game uses localStorage: saves stay in that browser on that device and do not automatically sync between devices or origins.
- Offline play requires an initial successful HTTPS load and service worker cache installation.
- GitHub Pages on a public repository publishes these files publicly. Do not upload private files or copyrighted source rulebooks.
- This package has been checked structurally, not physically tested on a Galaxy S26 Ultra.
